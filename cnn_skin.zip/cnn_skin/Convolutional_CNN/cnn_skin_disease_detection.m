clc
clear all
close all
% cd Database;
imds = imageDatastore('C:\Users\Mahsa\Desktop\Tasks\9-#P3094-skin-matlab-cnn\cnn_skin\Convolutional_CNN',...
    'IncludeSubfolders',true,... 
    'LabelSource','foldernames');

[Data,testData]= splitEachLabel(imds,0.8,'randomize');

% Training files 
[trainData] =Data;

layers = [
    imageInputLayer([256 256 3],'Name','input')
    
    convolution2dLayer(5,16,'Padding','same','Name','conv_1')
    batchNormalizationLayer('Name','BN_1')
    reluLayer('Name','relu_1')
    
    convolution2dLayer(3,32,'Padding','same','Stride',2,'Name','conv_2')
    batchNormalizationLayer('Name','BN_2')
    reluLayer('Name','relu_2')
    convolution2dLayer(3,32,'Padding','same','Name','conv_3')
    batchNormalizationLayer('Name','BN_3')
    reluLayer('Name','relu_3')
    
    additionLayer(2,'Name','add')
    
    averagePooling2dLayer(2,'Stride',2,'Name','avpool')
    fullyConnectedLayer(8,'Name','fc')
    softmaxLayer('Name','softmax')
    classificationLayer('Name','classOutput')];

% Create a layer graph from the layer array. layerGraph connects all the layers in layers sequentially. Plot the layer graph.
lgraph = layerGraph(layers);
figure
plot(lgraph)

% Create the 1-by-1 convolutional layer and add it to the layer graph. Specify the number of convolutional filters and the stride so that the activation size matches the activation size of the 'relu_3' layer. This arrangement enables the addition layer to add the outputs of the 'skipConv' and 'relu_3' layers. To check that the layer is in the graph, plot the layer graph.
skipConv = convolution2dLayer(1,32,'Stride',2,'Name','skipConv');
lgraph = addLayers(lgraph,skipConv);
figure
plot(lgraph)

% Create the shortcut connection from the 'relu_1' layer to the 'add' layer. Because you specified two as the number of inputs to the addition layer when you created it, the layer has two inputs named 'in1' and 'in2'. The 'relu_3' layer is already connected to the 'in1' input. Connect the 'relu_1' layer to the 'skipConv' layer and the 'skipConv' layer to the 'in2' input of the 'add' layer. The addition layer now sums the outputs of the 'relu_3' and 'skipConv' layers. To check that the layers are connected correctly, plot the layer graph.
lgraph = connectLayers(lgraph,'relu_1','skipConv');
lgraph = connectLayers(lgraph,'skipConv','add/in2');
figure
plot(lgraph);


options = trainingOptions('adam', ...
    'MiniBatchSize',128, ...
    'MaxEpochs',10, ... % was 6
    'ValidationFrequency',5, ...
    'InitialLearnRate',1e-4,'Plots','training-progress');


% % network training 

[convnet, traininfo] = trainNetwork(trainData,lgraph,options);

cd 'C:\Users\Mahsa\Desktop\Tasks\9-#P3094-skin-matlab-cnn\cnn_skin\Correlation';
inp=input('Enter input :'); 
% 'Actinic.jpg' or 'Basal.jpg' or 'Dermatofibroma.jpg' or 'Keratosis.jpg' or 'Melanoma.jpg' or 'Nevous.jpg' or 'Vascular.jpg'

    I = imread(inp);
    
    figure,imshow(I)
 
% % %     done classification 
     class = classify(convnet,I);

     msgbox(char(class))
